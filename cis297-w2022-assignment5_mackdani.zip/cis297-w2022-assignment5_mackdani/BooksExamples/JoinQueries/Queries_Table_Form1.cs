﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JoinQueries
{
    /// <summary>
    /// This program uses the books database to make a connection to the authors and titles table. It is then queried with buttons.
    /// </summary>
    /// <Student>Daniel Mack</Student>
    /// <Class>CIS297</Class>
    /// <Semester>Winter 2022</Semester>
    public partial class JoiningTableData : Form
    {
        /// <summary>
        /// Initializes components of the project
        /// </summary>
        public JoiningTableData()
        {
            InitializeComponent();
        }

        /// <summary>
        /// On form load, append the text of the textbox for each of the specified queries
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void JoiningTableData_Load(object sender, EventArgs e)
        {
            var dbcontext = new BooksExamples.BooksEntities();

            var authorsAndTitles =
                from author in dbcontext.Authors
                from book in author.Titles
                orderby book.Title1
                select new { author.FirstName, author.LastName, book.Title1 };

            outputTextBox.AppendText("Authors and Titles:");

            foreach(var element in authorsAndTitles)
            {
                outputTextBox.AppendText($"\r\n\t{element.FirstName,-10} " +
                    $"{element.LastName,-10} {element.Title1,-10}");
            }

            outputTextBox.AppendText("\r\n\r\nAuthors and Titles Pt2:");

            var authorsAndTitles2 =
                from author in dbcontext.Authors
                from book in author.Titles
                orderby book.Title1, author.LastName, author.FirstName
                select new { author.FirstName, author.LastName, book.Title1 };

            foreach (var element in authorsAndTitles2)
            {
                outputTextBox.AppendText($"\r\n\t{element.FirstName,-10} " +
                    $"{element.LastName,-10} {element.Title1,-10}");
            }

            outputTextBox.AppendText("\r\n\r\nAuthors and Titles Pt3:");

            var authorsAndTitles3 =
                from book in dbcontext.Titles
                orderby book.Title1
                select new
                {
                    Title = book.Title1,
                    Name =
                    from author in book.Authors
                    orderby author.LastName, author.FirstName
                    select author.FirstName + " " + author.LastName
                };

            foreach (var book in authorsAndTitles3)
            {
                outputTextBox.AppendText($"\r\n\t{book.Title}:");

                foreach (var Name in book.Name)
                {
                    outputTextBox.AppendText($"\r\n\t\t{Name}");
                }
            }           
        }
    }
}
